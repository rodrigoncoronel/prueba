#include <stdio.h>
#include <stdlib.h>
#include "lib.h"


int main()
{
    int resultado, respuesta;
    printf("Hello world!\n");
    respuesta = getInt("\nEdad", "Error, entre 0-199", 3, 0, 199, &resultado);
    if (respuesta == 0)
    {
        printf("la edad es %d", resultado);
    }

    return 0;
}
