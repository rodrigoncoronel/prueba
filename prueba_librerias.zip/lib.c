#include <stdio.h>
#include <stdlib.h>

int getInt(char* mensaje, char* mensajeError, int intentos, int minimo, int maximo, int *resultado)
{
    int retorno = -1;
    int ciclo = 0;
    int datoPedido;


    do
    {
        printf("%s", mensaje);
        scanf("%d", &datoPedido);

        if(datoPedido < maximo && datoPedido > minimo)
        {
            *resultado = datoPedido;
            retorno = 0;
            break;
        }
        else if (datoPedido < maximo)
        {
            retorno = -1;
        }
        else
        {
            retorno = -2;
        }

        printf("%s", mensajeError);

        ciclo++;
    }while(ciclo < intentos);

    return retorno;
}
