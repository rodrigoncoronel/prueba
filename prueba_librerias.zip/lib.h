int getInt(char* Mensaje, char * mensajeError, int intentos, int minimo, int maximo, int* resultado);
