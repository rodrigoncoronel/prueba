#include <stdio.h>
#include <stdlib.h>

int getInt(char* Mensaje, char * mensajeError, int intentos, int minimo, int maximo, int* resultado);

int main()
{
    int resultado, pt;
    printf("Hello world!\n");
    pt = getInt("\nEdad", "Error, entre 0-199", 3, 0, 199, &resultado);
    if (pt == 0)
    {
        printf("la edad es %d", resultado);
    }

    return 0;
}

int getInt(char* mensaje, char* mensajeError, int intentos, int minimo, int maximo, int *resultado)
{
    int retorno = -1;
    int ciclo = 0;
    int datoPedido;


    do
    {
        printf("%s", mensaje);
        scanf("%d", &datoPedido);

        if(datoPedido < maximo && datoPedido > minimo)
        {
            *resultado = datoPedido;
            retorno = 0;
            break;
        }
        else if (datoPedido < maximo)
        {
            retorno = -1;
        }
        else
        {
            retorno = -2;
        }

        printf("%s", mensajeError);

        ciclo++;
    }while(ciclo < intentos);

    return retorno;
}

 /* int ciclo = 0;
    while (ciclo < intentos)
    {
        if(*resultado < maximo && *resultado > minimo)
        {
            *mensaje = "Todo bien";
            retorno = 0;
        }
        else
        {
            *mensaje = "Rango no valido";
        }
        ciclo++;
    }*/
